process.env.JWT_ACCESS_SECRET = 'test-secret-test-secret-test-secret-123456';
process.env.DATABASE_PATH = ':memory:';
process.env.NODE_ENV = 'test';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');

const db = require('../src/db');
const app = require('../src/app');

let server, base;
const call = async (method, path, { token, body, cookie } = {}) => {
  const res = await fetch(base + path, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
      ...(cookie && { Cookie: cookie }),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  return { status: res.status, body: text ? JSON.parse(text) : null, res };
};
const cookieOf = (res) => (res.headers.get('set-cookie') || '').split(';')[0];

before(async () => {
  const now = Date.now();
  db.prepare(
    `INSERT INTO users (id,email,password_hash,full_name,role,created_at,updated_at) VALUES (?,?,?,?,?,?,?)`
  ).run(crypto.randomUUID(), 'admin@kgosi.test', bcrypt.hashSync('AdminPass!1234', 4), 'Admin', 'admin', now, now);
  await new Promise((r) => (server = app.listen(0, r)));
  base = `http://localhost:${server.address().port}`;
});
after(() => server.close());

test('full RBAC flow', async () => {
  // unauthenticated
  assert.equal((await call('GET', '/api/projects')).status, 401);

  // admin login
  const login = await call('POST', '/api/auth/login', { body: { email: 'admin@kgosi.test', password: 'AdminPass!1234' } });
  assert.equal(login.status, 200);
  const admin = login.body.accessToken;
  const adminId = login.body.user.id;

  // admin creates staff + clients
  const mk = (email, role) =>
    call('POST', '/api/users', { token: admin, body: { email, fullName: 'Test User', password: 'LongPassword!1', role } });
  const arch = (await mk('arch@kgosi.test', 'architect')).body.user;
  const c1 = (await mk('c1@kgosi.test', 'client')).body.user;
  const c2 = (await mk('c2@kgosi.test', 'client')).body.user;
  assert.equal((await mk('c1@kgosi.test', 'client')).status, 409);

  const archLogin = await call('POST', '/api/auth/login', { body: { email: 'arch@kgosi.test', password: 'LongPassword!1' } });
  const c1Login = await call('POST', '/api/auth/login', { body: { email: 'c1@kgosi.test', password: 'LongPassword!1' } });
  const c2Login = await call('POST', '/api/auth/login', { body: { email: 'c2@kgosi.test', password: 'LongPassword!1' } });
  const archT = archLogin.body.accessToken, c1T = c1Login.body.accessToken, c2T = c2Login.body.accessToken;

  // clients can't manage users or create projects
  assert.equal((await call('GET', '/api/users', { token: c1T })).status, 403);
  assert.equal((await call('POST', '/api/projects', { token: c1T, body: { name: 'Nope' } })).status, 403);
  // architects can read users but not create them
  assert.equal((await call('GET', '/api/users', { token: archT })).status, 200);
  assert.equal((await call('POST', '/api/users', { token: archT, body: {} })).status, 403);

  // ownership: architect creates a project, only c1 is added
  const proj = (await call('POST', '/api/projects', { token: archT, body: { name: 'Gaborone Office Tower' } })).body.project;
  assert.equal((await call('GET', `/api/projects/${proj.id}`, { token: c1T })).status, 404);
  assert.equal((await call('POST', `/api/projects/${proj.id}/members`, { token: archT, body: { userId: c1.id } })).status, 204);
  assert.equal((await call('GET', `/api/projects/${proj.id}`, { token: c1T })).status, 200);
  assert.equal((await call('GET', `/api/projects/${proj.id}`, { token: c2T })).status, 404);
  assert.equal((await call('GET', '/api/projects', { token: c1T })).body.projects.length, 1);
  assert.equal((await call('GET', '/api/projects', { token: c2T })).body.projects.length, 0);
  assert.equal((await call('PATCH', `/api/projects/${proj.id}`, { token: c1T, body: { name: 'Hacked' } })).status, 403);

  // admin safety rails
  assert.equal((await call('PATCH', `/api/users/${adminId}/role`, { token: admin, body: { role: 'client' } })).status, 400);
  assert.equal((await call('PATCH', `/api/users/${adminId}/status`, { token: admin, body: { isActive: false } })).status, 400);
  assert.equal((await call('DELETE', `/api/users/${adminId}`, { token: admin })).status, 400);

  // role change is effective immediately, even with an existing token
  assert.equal((await call('PATCH', `/api/users/${arch.id}/role`, { token: admin, body: { role: 'client' } })).status, 200);
  assert.equal((await call('POST', '/api/projects', { token: archT, body: { name: 'Should fail' } })).status, 403);

  // deactivation kills the session
  await call('PATCH', `/api/users/${c2.id}/status`, { token: admin, body: { isActive: false } });
  assert.equal((await call('GET', '/api/auth/me', { token: c2T })).status, 401);

  // invalid role rejected
  assert.equal((await call('PATCH', `/api/users/${c1.id}/role`, { token: admin, body: { role: 'superuser' } })).status, 400);
});

test('refresh rotation and reuse detection', async () => {
  const login = await call('POST', '/api/auth/login', { body: { email: 'admin@kgosi.test', password: 'AdminPass!1234' } });
  const oldCookie = cookieOf(login.res);
  assert.match(oldCookie, /^kgosi_refresh=/);

  const r1 = await call('POST', '/api/auth/refresh', { cookie: oldCookie });
  assert.equal(r1.status, 200);
  const newCookie = cookieOf(r1.res);
  assert.notEqual(newCookie, oldCookie);

  // replaying the old token fails and burns the whole family
  assert.equal((await call('POST', '/api/auth/refresh', { cookie: oldCookie })).status, 401);
  assert.equal((await call('POST', '/api/auth/refresh', { cookie: newCookie })).status, 401);
});

test('registration is closed by default, lockout works', async () => {
  assert.equal(
    (await call('POST', '/api/auth/register', { body: { email: 'x@y.com', fullName: 'X Y', password: 'LongPassword!1' } })).status,
    403
  );
  for (let i = 0; i < 5; i++) {
    assert.equal((await call('POST', '/api/auth/login', { body: { email: 'c1@kgosi.test', password: 'wrong-password' } })).status, 401);
  }
  // now locked, even with the right password
  assert.equal((await call('POST', '/api/auth/login', { body: { email: 'c1@kgosi.test', password: 'LongPassword!1' } })).status, 423);
});

test('admin dashboard, users/owners lists, owner role', async () => {
  const login = await call('POST', '/api/auth/login', { body: { email: 'admin@kgosi.test', password: 'AdminPass!1234' } });
  const admin = login.body.accessToken;
  assert.equal(login.body.user.redirectTo, '/admin');
  assert.deepEqual(login.body.user.nav.map((n) => n.label), ['Users', 'Owners']);

  const mk = (email, role) =>
    call('POST', '/api/users', { token: admin, body: { email, fullName: 'Test User', password: 'LongPassword!1', role } });
  assert.equal((await mk('owner@kgosi.test', 'owner')).status, 201);
  await mk('staff@kgosi.test', 'editor');

  const owners = await call('GET', '/api/admin/owners', { token: admin });
  assert.equal(owners.status, 200);
  assert.deepEqual(owners.body.owners.map((o) => o.email), ['owner@kgosi.test']);
  const users = await call('GET', '/api/admin/users', { token: admin });
  assert.ok(users.body.users.length >= 1);
  assert.ok(users.body.users.every((u) => u.role !== 'owner'));
  assert.equal((await call('GET', '/api/admin/dashboard', { token: admin })).body.counts.owner, 1);

  // owner: sees all projects and users, but cannot enter the admin area or manage accounts
  const ownerLogin = await call('POST', '/api/auth/login', { body: { email: 'owner@kgosi.test', password: 'LongPassword!1' } });
  const o = ownerLogin.body.accessToken;
  assert.equal(ownerLogin.body.user.redirectTo, '/owner');
  assert.equal((await call('GET', '/api/projects', { token: o })).status, 200);
  assert.equal((await call('GET', '/api/users', { token: o })).status, 200);
  assert.equal((await call('GET', '/api/admin/owners', { token: o })).status, 403);
  assert.equal((await call('POST', '/api/users', { token: o, body: {} })).status, 403);

  // editor can't reach admin area either
  const ed = (await call('POST', '/api/auth/login', { body: { email: 'staff@kgosi.test', password: 'LongPassword!1' } })).body.accessToken;
  assert.equal((await call('GET', '/api/admin/users', { token: ed })).status, 403);
  assert.equal((await call('GET', '/api/admin/users')).status, 401);
});
