/**
 * Single source of truth for roles and what each role may do.
 * Routes check PERMISSIONS, never role names, so access rules change in one place.
 */

const ROLES = Object.freeze({
  ADMIN: 'admin',         // full control, including users, owners and roles
  OWNER: 'owner',         // firm owners: oversight of all projects and users, no system admin
  ARCHITECT: 'architect', // staff: manage projects and portfolio content
  EDITOR: 'editor',       // marketing/content: manage website content only
  CLIENT: 'client',       // external: sees only projects they belong to
});

const PERMISSIONS = Object.freeze({
  USERS_READ: 'users:read',
  USERS_CREATE: 'users:create',
  USERS_UPDATE: 'users:update',
  USERS_DELETE: 'users:delete',
  USERS_ASSIGN_ROLE: 'users:assign_role',
  ADMIN_DASHBOARD: 'admin:dashboard', // admin-only area with the Users and Owners lists

  PROJECTS_READ_ALL: 'projects:read_all',
  PROJECTS_READ_OWN: 'projects:read_own',
  PROJECTS_CREATE: 'projects:create',
  PROJECTS_UPDATE: 'projects:update',
  PROJECTS_DELETE: 'projects:delete',

  CONTENT_CREATE: 'content:create',
  CONTENT_UPDATE: 'content:update',
  CONTENT_DELETE: 'content:delete',
});

const ROLE_PERMISSIONS = Object.freeze({
  [ROLES.ADMIN]: ['*'],
  [ROLES.OWNER]: [
    PERMISSIONS.USERS_READ,
    PERMISSIONS.PROJECTS_READ_ALL,
    PERMISSIONS.PROJECTS_UPDATE,
  ],
  [ROLES.ARCHITECT]: [
    PERMISSIONS.USERS_READ,
    PERMISSIONS.PROJECTS_READ_ALL,
    PERMISSIONS.PROJECTS_CREATE,
    PERMISSIONS.PROJECTS_UPDATE,
    PERMISSIONS.CONTENT_CREATE,
    PERMISSIONS.CONTENT_UPDATE,
  ],
  [ROLES.EDITOR]: [
    PERMISSIONS.CONTENT_CREATE,
    PERMISSIONS.CONTENT_UPDATE,
    PERMISSIONS.CONTENT_DELETE,
  ],
  [ROLES.CLIENT]: [PERMISSIONS.PROJECTS_READ_OWN],
});

const ALL_ROLES = Object.values(ROLES);

// Where each role lands after login, and the links its dashboard shows.
// The frontend can render `nav` directly instead of hard-coding it per role.
const ROLE_HOME = Object.freeze({
  [ROLES.ADMIN]: '/admin',
  [ROLES.OWNER]: '/owner',
  [ROLES.ARCHITECT]: '/staff',
  [ROLES.EDITOR]: '/staff',
  [ROLES.CLIENT]: '/portal',
});

const ROLE_NAV = Object.freeze({
  [ROLES.ADMIN]: [
    { label: 'Users', path: '/admin/users', api: '/api/admin/users' },
    { label: 'Owners', path: '/admin/owners', api: '/api/admin/owners' },
  ],
  [ROLES.OWNER]: [
    { label: 'Projects', path: '/owner/projects', api: '/api/projects' },
    { label: 'Users', path: '/owner/users', api: '/api/users' },
  ],
  [ROLES.ARCHITECT]: [{ label: 'Projects', path: '/staff/projects', api: '/api/projects' }],
  [ROLES.EDITOR]: [],
  [ROLES.CLIENT]: [{ label: 'My projects', path: '/portal/projects', api: '/api/projects' }],
});

const sessionInfo = (role) => ({ redirectTo: ROLE_HOME[role], nav: ROLE_NAV[role] || [] });

function can(role, permission) {
  const granted = ROLE_PERMISSIONS[role] || [];
  return granted.includes('*') || granted.includes(permission);
}

module.exports = { ROLES, PERMISSIONS, ROLE_PERMISSIONS, ALL_ROLES, ROLE_HOME, ROLE_NAV, sessionInfo, can };
