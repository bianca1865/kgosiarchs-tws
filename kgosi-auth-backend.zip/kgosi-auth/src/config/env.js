require('dotenv').config();

const env = {
  nodeEnv: process.env.NODE_ENV || 'development',
  port: Number(process.env.PORT || 4000),
  clientOrigin: process.env.CLIENT_ORIGIN || 'http://localhost:5173',
  jwtSecret: process.env.JWT_ACCESS_SECRET,
  accessTtl: process.env.ACCESS_TOKEN_TTL || '15m',
  refreshTtlDays: Number(process.env.REFRESH_TOKEN_TTL_DAYS || 14),
  databasePath: process.env.DATABASE_PATH || './data/kgosi.db',
  allowPublicRegistration: process.env.ALLOW_PUBLIC_REGISTRATION === 'true',
};

env.isProd = env.nodeEnv === 'production';

if (!env.jwtSecret || env.jwtSecret.length < 32) {
  throw new Error('JWT_ACCESS_SECRET must be set and at least 32 characters long.');
}

module.exports = env;
