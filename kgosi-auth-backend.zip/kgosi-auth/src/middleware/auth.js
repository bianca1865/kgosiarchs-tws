const db = require('../db');
const { can, ALL_ROLES } = require('../config/permissions');
const { verifyAccessToken } = require('../utils/tokens');
const { unauthorized, forbidden } = require('../utils/errors');

/** Requires a valid access token. Sets req.user = { id, email, fullName, role }. */
function authenticate(req, _res, next) {
  const header = req.headers.authorization || '';
  const [scheme, token] = header.split(' ');
  if (scheme !== 'Bearer' || !token) return next(unauthorized());

  let payload;
  try {
    payload = verifyAccessToken(token);
  } catch {
    return next(unauthorized('Invalid or expired token'));
  }

  const user = db
    .prepare('SELECT id, email, full_name, role, is_active FROM users WHERE id = ?')
    .get(payload.sub);

  if (!user || !user.is_active) return next(unauthorized('Account not available'));

  req.user = { id: user.id, email: user.email, fullName: user.full_name, role: user.role };
  next();
}

/** Allow only the listed roles. Prefer requirePermission for new routes. */
function requireRole(...roles) {
  for (const r of roles) if (!ALL_ROLES.includes(r)) throw new Error(`Unknown role: ${r}`);
  return (req, _res, next) => {
    if (!req.user) return next(unauthorized());
    if (!roles.includes(req.user.role)) return next(forbidden());
    next();
  };
}

/** Require ALL listed permissions (see config/permissions.js). */
function requirePermission(...permissions) {
  return (req, _res, next) => {
    if (!req.user) return next(unauthorized());
    if (!permissions.every((p) => can(req.user.role, p))) return next(forbidden());
    next();
  };
}

module.exports = { authenticate, requireRole, requirePermission };
