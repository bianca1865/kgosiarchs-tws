const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const env = require('../config/env');

const ISSUER = 'kgosi-architects';

function signAccessToken(user) {
  // Only the user id goes in the token. Role is read fresh from the DB on every
  // request, so a demotion or deactivation takes effect immediately.
  return jwt.sign({ sub: user.id }, env.jwtSecret, {
    algorithm: 'HS256',
    expiresIn: env.accessTtl,
    issuer: ISSUER,
  });
}

function verifyAccessToken(token) {
  return jwt.verify(token, env.jwtSecret, { algorithms: ['HS256'], issuer: ISSUER });
}

const generateRefreshToken = () => crypto.randomBytes(48).toString('base64url');
const hashToken = (token) => crypto.createHash('sha256').update(token).digest('hex');

module.exports = { signAccessToken, verifyAccessToken, generateRefreshToken, hashToken };
