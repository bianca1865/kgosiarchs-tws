const toUserDto = (u) => ({
  id: u.id,
  email: u.email,
  fullName: u.full_name,
  role: u.role,
  isActive: !!u.is_active,
  createdAt: u.created_at,
});

module.exports = { toUserDto };
