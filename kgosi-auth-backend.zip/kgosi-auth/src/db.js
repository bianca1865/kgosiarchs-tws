const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const env = require('./config/env');

const dbFile = env.databasePath === ':memory:' ? ':memory:' : path.resolve(env.databasePath);
if (dbFile !== ':memory:') fs.mkdirSync(path.dirname(dbFile), { recursive: true });

const db = new Database(dbFile);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));

// Migration: databases created before the 'owner' role existed have an older CHECK
// constraint on users.role. SQLite can't alter a CHECK, so rebuild the table once.
const usersDef = db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='users'").get();
if (usersDef && !usersDef.sql.includes("'owner'")) {
  db.pragma('foreign_keys = OFF');
  db.transaction(() => {
    db.exec(`
      CREATE TABLE users_new (
        id              TEXT PRIMARY KEY,
        email           TEXT NOT NULL UNIQUE COLLATE NOCASE,
        password_hash   TEXT NOT NULL,
        full_name       TEXT NOT NULL,
        role            TEXT NOT NULL CHECK (role IN ('admin','owner','architect','editor','client')),
        is_active       INTEGER NOT NULL DEFAULT 1,
        failed_attempts INTEGER NOT NULL DEFAULT 0,
        locked_until    INTEGER,
        created_at      INTEGER NOT NULL,
        updated_at      INTEGER NOT NULL
      );
      INSERT INTO users_new SELECT id, email, password_hash, full_name, role, is_active,
                                   failed_attempts, locked_until, created_at, updated_at FROM users;
      DROP TABLE users;
      ALTER TABLE users_new RENAME TO users;
    `);
  })();
  db.pragma('foreign_keys = ON');
}

module.exports = db;
