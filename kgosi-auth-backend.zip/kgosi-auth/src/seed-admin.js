// Creates the first admin and owner accounts. Run once: npm run seed:admin
// Credentials come from .env if set, otherwise the defaults below.
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const db = require('./db');

const DEFAULTS = {
  admin: { email: 'admin@kgosiarchitects.example', password: 'kgosiarchitects267', name: 'Site Administrator' },
  owner: { email: 'owner@kgosiarchitects.example', password: 'kgosiowner267', name: 'Firm Owner' },
};

function seed(role) {
  const d = DEFAULTS[role];
  const P = role.toUpperCase();
  const email = (process.env[`${P}_EMAIL`] || d.email).trim().toLowerCase();
  const pw = process.env[`${P}_PASSWORD`] || d.password;
  const name = process.env[`${P}_NAME`] || d.name;

  if (pw.length < 10 || pw.length > 72) {
    console.error(`${P}_PASSWORD must be 10-72 characters`);
    process.exit(1);
  }
  if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) {
    console.log(`${role} ${email} already exists, skipping.`);
    return;
  }
  const now = Date.now();
  db.prepare(
    `INSERT INTO users (id, email, password_hash, full_name, role, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(crypto.randomUUID(), email, bcrypt.hashSync(pw, 12), name, role, now, now); // stored hashed, never plain
  console.log(`${role} created: ${email}`);
}

seed('admin');
seed('owner');
