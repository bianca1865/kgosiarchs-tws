const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { z } = require('zod');

const db = require('../db');
const { ALL_ROLES, ROLES, PERMISSIONS } = require('../config/permissions');
const { authenticate, requirePermission } = require('../middleware/auth');
const { badRequest, conflict, notFound } = require('../utils/errors');
const { toUserDto } = require('../utils/dto');

const router = express.Router();
router.use(authenticate);

const roleEnum = z.enum(ALL_ROLES);
const createSchema = z.object({
  email: z.string().trim().toLowerCase().email(),
  fullName: z.string().trim().min(2).max(100),
  password: z.string().min(10).max(72),
  role: roleEnum,
});

const toDto = toUserDto;

const getUser = (id) => {
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  if (!u) throw notFound('User not found');
  return u;
};

// Guard: the system must never be left without an active admin.
function assertNotLastAdmin(user) {
  if (user.role !== ROLES.ADMIN || !user.is_active) return;
  const { n } = db
    .prepare("SELECT COUNT(*) AS n FROM users WHERE role = 'admin' AND is_active = 1")
    .get();
  if (n <= 1) throw badRequest('Cannot remove or demote the last active admin');
}

const revokeSessions = (id) =>
  db.prepare('UPDATE refresh_tokens SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL').run(Date.now(), id);

// GET /api/users?role=client
router.get('/', requirePermission(PERMISSIONS.USERS_READ), (req, res) => {
  const role = req.query.role ? roleEnum.parse(req.query.role) : null;
  const rows = role
    ? db.prepare('SELECT * FROM users WHERE role = ? ORDER BY created_at DESC').all(role)
    : db.prepare('SELECT * FROM users ORDER BY created_at DESC').all();
  res.json({ users: rows.map(toDto) });
});

// POST /api/users  (admin creates staff or client accounts)
router.post('/', requirePermission(PERMISSIONS.USERS_CREATE), async (req, res) => {
  const data = createSchema.parse(req.body);
  if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(data.email)) {
    throw conflict('An account with that email already exists');
  }
  const now = Date.now();
  const id = crypto.randomUUID();
  db.prepare(
    `INSERT INTO users (id, email, password_hash, full_name, role, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(id, data.email, await bcrypt.hash(data.password, 12), data.fullName, data.role, now, now);
  res.status(201).json({ user: toDto(getUser(id)) });
});

// PATCH /api/users/:id/role
router.patch('/:id/role', requirePermission(PERMISSIONS.USERS_ASSIGN_ROLE), (req, res) => {
  const { role } = z.object({ role: roleEnum }).parse(req.body);
  const target = getUser(req.params.id);

  if (target.id === req.user.id) throw badRequest('You cannot change your own role');
  if (role !== ROLES.ADMIN) assertNotLastAdmin(target);

  db.prepare('UPDATE users SET role = ?, updated_at = ? WHERE id = ?').run(role, Date.now(), target.id);
  res.json({ user: toDto(getUser(target.id)) });
});

// PATCH /api/users/:id/status  { isActive: boolean }
router.patch('/:id/status', requirePermission(PERMISSIONS.USERS_UPDATE), (req, res) => {
  const { isActive } = z.object({ isActive: z.boolean() }).parse(req.body);
  const target = getUser(req.params.id);

  if (!isActive) {
    if (target.id === req.user.id) throw badRequest('You cannot deactivate yourself');
    assertNotLastAdmin(target);
  }

  db.prepare('UPDATE users SET is_active = ?, updated_at = ? WHERE id = ?').run(isActive ? 1 : 0, Date.now(), target.id);
  if (!isActive) revokeSessions(target.id);
  res.json({ user: toDto(getUser(target.id)) });
});

// DELETE /api/users/:id
router.delete('/:id', requirePermission(PERMISSIONS.USERS_DELETE), (req, res) => {
  const target = getUser(req.params.id);
  if (target.id === req.user.id) throw badRequest('You cannot delete yourself');
  assertNotLastAdmin(target);
  db.prepare('DELETE FROM users WHERE id = ?').run(target.id);
  res.status(204).end();
});

module.exports = router;
