/**
 * Example of resource-level authorisation on top of role permissions:
 *  - staff (projects:read_all) see every project
 *  - clients (projects:read_own) see only projects they are a member of
 * Copy this pattern for documents, invoices, drawings, etc.
 */
const express = require('express');
const crypto = require('crypto');
const { z } = require('zod');

const db = require('../db');
const { can, PERMISSIONS } = require('../config/permissions');
const { authenticate, requirePermission } = require('../middleware/auth');
const { forbidden, notFound } = require('../utils/errors');

const router = express.Router();
router.use(authenticate);

const STATUSES = ['planning', 'design', 'construction', 'completed', 'on_hold'];
const createSchema = z.object({
  name: z.string().trim().min(2).max(150),
  description: z.string().trim().max(5000).optional(),
  status: z.enum(STATUSES).default('planning'),
});
const updateSchema = createSchema.partial().refine((v) => Object.keys(v).length > 0, 'Nothing to update');

const isMember = (projectId, userId) =>
  !!db.prepare('SELECT 1 FROM project_members WHERE project_id = ? AND user_id = ?').get(projectId, userId);

function loadProjectForUser(req) {
  const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(req.params.id);
  if (!project) throw notFound('Project not found');

  const { role, id: userId } = req.user;
  if (can(role, PERMISSIONS.PROJECTS_READ_ALL)) return project;
  // Return 404 (not 403) to clients so project ids can't be probed
  if (can(role, PERMISSIONS.PROJECTS_READ_OWN) && isMember(project.id, userId)) return project;
  throw notFound('Project not found');
}

// GET /api/projects
router.get('/', (req, res) => {
  const { role, id } = req.user;
  let rows;
  if (can(role, PERMISSIONS.PROJECTS_READ_ALL)) {
    rows = db.prepare('SELECT * FROM projects ORDER BY created_at DESC').all();
  } else if (can(role, PERMISSIONS.PROJECTS_READ_OWN)) {
    rows = db
      .prepare(
        `SELECT p.* FROM projects p
         JOIN project_members m ON m.project_id = p.id
         WHERE m.user_id = ? ORDER BY p.created_at DESC`
      )
      .all(id);
  } else {
    throw forbidden();
  }
  res.json({ projects: rows });
});

// GET /api/projects/:id
router.get('/:id', (req, res) => {
  res.json({ project: loadProjectForUser(req) });
});

// POST /api/projects
router.post('/', requirePermission(PERMISSIONS.PROJECTS_CREATE), (req, res) => {
  const data = createSchema.parse(req.body);
  const id = crypto.randomUUID();
  const now = Date.now();
  db.prepare(
    `INSERT INTO projects (id, name, description, status, created_by, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(id, data.name, data.description ?? null, data.status, req.user.id, now, now);
  res.status(201).json({ project: db.prepare('SELECT * FROM projects WHERE id = ?').get(id) });
});

// PATCH /api/projects/:id
router.patch('/:id', requirePermission(PERMISSIONS.PROJECTS_UPDATE), (req, res) => {
  const data = updateSchema.parse(req.body);
  const project = loadProjectForUser(req);
  const next = { ...project, ...data };
  db.prepare('UPDATE projects SET name = ?, description = ?, status = ?, updated_at = ? WHERE id = ?').run(
    next.name,
    next.description ?? null,
    next.status,
    Date.now(),
    project.id
  );
  res.json({ project: db.prepare('SELECT * FROM projects WHERE id = ?').get(project.id) });
});

// DELETE /api/projects/:id
router.delete('/:id', requirePermission(PERMISSIONS.PROJECTS_DELETE), (req, res) => {
  const project = loadProjectForUser(req);
  db.prepare('DELETE FROM projects WHERE id = ?').run(project.id);
  res.status(204).end();
});

// POST /api/projects/:id/members  { userId }
router.post('/:id/members', requirePermission(PERMISSIONS.PROJECTS_UPDATE), (req, res) => {
  const { userId } = z.object({ userId: z.string().min(1) }).parse(req.body);
  const project = loadProjectForUser(req);
  if (!db.prepare('SELECT 1 FROM users WHERE id = ? AND is_active = 1').get(userId)) {
    throw notFound('User not found');
  }
  db.prepare('INSERT OR IGNORE INTO project_members (project_id, user_id) VALUES (?, ?)').run(project.id, userId);
  res.status(204).end();
});

// DELETE /api/projects/:id/members/:userId
router.delete('/:id/members/:userId', requirePermission(PERMISSIONS.PROJECTS_UPDATE), (req, res) => {
  const project = loadProjectForUser(req);
  db.prepare('DELETE FROM project_members WHERE project_id = ? AND user_id = ?').run(project.id, req.params.userId);
  res.status(204).end();
});

module.exports = router;
