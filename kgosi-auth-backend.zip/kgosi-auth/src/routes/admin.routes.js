/**
 * Admin area. The admin dashboard links to two lists:
 *   /api/admin/users   -> everyone except owners (staff + clients)
 *   /api/admin/owners  -> owner accounts
 * Creating, changing roles and deactivating are done through /api/users.
 */
const express = require('express');
const db = require('../db');
const { ROLES, PERMISSIONS, ROLE_NAV } = require('../config/permissions');
const { authenticate, requirePermission } = require('../middleware/auth');
const { toUserDto } = require('../utils/dto');

const router = express.Router();
router.use(authenticate, requirePermission(PERMISSIONS.ADMIN_DASHBOARD));

// GET /api/admin/dashboard
router.get('/dashboard', (_req, res) => {
  const counts = Object.fromEntries(Object.values(ROLES).map((r) => [r, 0]));
  for (const row of db.prepare('SELECT role, COUNT(*) AS n FROM users GROUP BY role').all()) {
    counts[row.role] = row.n;
  }
  res.json({ counts, nav: ROLE_NAV[ROLES.ADMIN] });
});

// GET /api/admin/users
router.get('/users', (_req, res) => {
  const rows = db.prepare("SELECT * FROM users WHERE role != 'owner' ORDER BY created_at DESC").all();
  res.json({ users: rows.map(toUserDto) });
});

// GET /api/admin/owners
router.get('/owners', (_req, res) => {
  const rows = db.prepare("SELECT * FROM users WHERE role = 'owner' ORDER BY created_at DESC").all();
  res.json({ owners: rows.map(toUserDto) });
});

module.exports = router;
