const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { z } = require('zod');
const rateLimit = require('express-rate-limit');

const env = require('../config/env');
const db = require('../db');
const { ROLES, sessionInfo } = require('../config/permissions');
const { authenticate } = require('../middleware/auth');
const { signAccessToken, generateRefreshToken, hashToken } = require('../utils/tokens');
const { unauthorized, forbidden, conflict, AppError } = require('../utils/errors');

const router = express.Router();

const BCRYPT_ROUNDS = 12;
const MAX_FAILED_ATTEMPTS = 5;
const LOCK_MINUTES = 15;
const REFRESH_COOKIE = 'kgosi_refresh';
// Compared against when the email is unknown, so response time doesn't reveal which emails exist
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', BCRYPT_ROUNDS);

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many attempts. Try again later.' },
});

const password = z
  .string()
  .min(10, 'Password must be at least 10 characters')
  .max(72, 'Password must be at most 72 characters');

const registerSchema = z.object({
  email: z.string().trim().toLowerCase().email(),
  fullName: z.string().trim().min(2).max(100),
  password,
});
const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email(),
  password: z.string().min(1).max(200),
});
const changePasswordSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword: password,
});

const publicUser = (u) => ({
  id: u.id,
  email: u.email,
  fullName: u.full_name,
  role: u.role,
  ...sessionInfo(u.role), // redirectTo + nav links for this role
});

function setRefreshCookie(res, token) {
  res.cookie(REFRESH_COOKIE, token, {
    httpOnly: true,
    secure: env.isProd,
    sameSite: 'strict',
    path: '/api/auth',
    maxAge: env.refreshTtlDays * 24 * 60 * 60 * 1000,
  });
}

function startSession(req, res, user) {
  const refreshToken = generateRefreshToken();
  const now = Date.now();
  db.prepare(
    `INSERT INTO refresh_tokens (id, user_id, token_hash, expires_at, created_at, user_agent)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(
    crypto.randomUUID(),
    user.id,
    hashToken(refreshToken),
    now + env.refreshTtlDays * 24 * 60 * 60 * 1000,
    now,
    (req.headers['user-agent'] || '').slice(0, 255)
  );
  setRefreshCookie(res, refreshToken);
  return signAccessToken(user);
}

const revokeAllTokens = (userId) =>
  db
    .prepare('UPDATE refresh_tokens SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL')
    .run(Date.now(), userId);

// POST /api/auth/register  (public self-signup creates CLIENT accounts only)
router.post('/register', authLimiter, async (req, res) => {
  if (!env.allowPublicRegistration) throw forbidden('Registration is by invitation only');

  const data = registerSchema.parse(req.body);
  if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(data.email)) {
    throw conflict('An account with that email already exists');
  }

  const now = Date.now();
  const user = {
    id: crypto.randomUUID(),
    email: data.email,
    full_name: data.fullName,
    role: ROLES.CLIENT, // never taken from the request body
  };
  db.prepare(
    `INSERT INTO users (id, email, password_hash, full_name, role, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(user.id, user.email, await bcrypt.hash(data.password, BCRYPT_ROUNDS), user.full_name, user.role, now, now);

  res.status(201).json({ accessToken: startSession(req, res, user), user: publicUser(user) });
});

// POST /api/auth/login
router.post('/login', authLimiter, async (req, res) => {
  const { email, password: pw } = loginSchema.parse(req.body);
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);

  if (!user) {
    await bcrypt.compare(pw, DUMMY_HASH);
    throw unauthorized('Invalid email or password');
  }

  if (user.locked_until && user.locked_until > Date.now()) {
    throw new AppError(423, 'Account temporarily locked. Try again later.');
  }

  const ok = await bcrypt.compare(pw, user.password_hash);
  if (!ok) {
    const attempts = user.failed_attempts + 1;
    if (attempts >= MAX_FAILED_ATTEMPTS) {
      db.prepare('UPDATE users SET failed_attempts = 0, locked_until = ? WHERE id = ?').run(
        Date.now() + LOCK_MINUTES * 60 * 1000,
        user.id
      );
    } else {
      db.prepare('UPDATE users SET failed_attempts = ? WHERE id = ?').run(attempts, user.id);
    }
    throw unauthorized('Invalid email or password');
  }

  if (!user.is_active) throw forbidden('This account has been deactivated');

  db.prepare('UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?').run(user.id);
  res.json({ accessToken: startSession(req, res, user), user: publicUser(user) });
});

// POST /api/auth/refresh  (rotates the refresh token; reuse of an old one revokes everything)
router.post('/refresh', authLimiter, (req, res) => {
  const presented = req.cookies?.[REFRESH_COOKIE];
  if (!presented) throw unauthorized('No refresh token');

  const row = db.prepare('SELECT * FROM refresh_tokens WHERE token_hash = ?').get(hashToken(presented));
  if (!row) throw unauthorized('Invalid refresh token');

  if (row.revoked_at) {
    // A rotated/revoked token was replayed: assume theft and kill every session for this user.
    revokeAllTokens(row.user_id);
    res.clearCookie(REFRESH_COOKIE, { path: '/api/auth' });
    throw unauthorized('Session no longer valid. Please sign in again.');
  }
  if (row.expires_at < Date.now()) throw unauthorized('Session expired');

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(row.user_id);
  if (!user || !user.is_active) throw unauthorized('Account not available');

  db.prepare('UPDATE refresh_tokens SET revoked_at = ? WHERE id = ?').run(Date.now(), row.id);
  res.json({ accessToken: startSession(req, res, user), user: publicUser(user) });
});

// POST /api/auth/logout
router.post('/logout', (req, res) => {
  const presented = req.cookies?.[REFRESH_COOKIE];
  if (presented) {
    db.prepare('UPDATE refresh_tokens SET revoked_at = ? WHERE token_hash = ? AND revoked_at IS NULL').run(
      Date.now(),
      hashToken(presented)
    );
  }
  res.clearCookie(REFRESH_COOKIE, { path: '/api/auth' });
  res.status(204).end();
});

// GET /api/auth/me
router.get('/me', authenticate, (req, res) => {
  res.json({ user: { ...req.user, ...sessionInfo(req.user.role) } });
});

// POST /api/auth/change-password  (signs out all other devices)
router.post('/change-password', authenticate, authLimiter, async (req, res) => {
  const { currentPassword, newPassword } = changePasswordSchema.parse(req.body);
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);

  if (!(await bcrypt.compare(currentPassword, user.password_hash))) {
    throw unauthorized('Current password is incorrect');
  }

  db.prepare('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?').run(
    await bcrypt.hash(newPassword, BCRYPT_ROUNDS),
    Date.now(),
    user.id
  );
  revokeAllTokens(user.id);
  res.json({ accessToken: startSession(req, res, user), user: publicUser(user) });
});

module.exports = router;
