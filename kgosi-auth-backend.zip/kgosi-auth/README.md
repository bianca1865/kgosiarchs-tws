# Kgosi Architects – Auth & Roles API

Node.js + Express + SQLite. Handles sign-in, sessions and role-based access only.

## Run
```
npm install
cp .env.example .env      # set JWT_ACCESS_SECRET, ADMIN_* values
npm run seed:admin        # creates the first admin
npm run dev
npm test
```

## Roles
| Role | Can do |
|---|---|
| admin | Everything, including users, owners and roles |
| owner | Firm owners: read all users and projects, edit projects. No account management |
| architect | Read users; create/edit projects; manage content |
| editor | Manage website content only |
| client | See only projects they are a member of |

Edit `src/config/permissions.js` to change what a role can do. Routes check permissions, not role names.

## Admin login
Credentials come from `.env` (never hard-coded). Set `ADMIN_EMAIL` / `ADMIN_PASSWORD` (and optionally `OWNER_EMAIL` / `OWNER_PASSWORD`), then run `npm run seed:admin`.
Login returns `redirectTo` and `nav` for the role. The admin gets two links: **Users** (`/api/admin/users`) and **Owners** (`/api/admin/owners`).

## Endpoints
| Method | Path | Access |
|---|---|---|
| POST | /api/auth/login | public |
| POST | /api/auth/register | public, only if ALLOW_PUBLIC_REGISTRATION=true (client role) |
| POST | /api/auth/refresh | refresh cookie |
| POST | /api/auth/logout | public |
| GET | /api/auth/me | signed in |
| POST | /api/auth/change-password | signed in |
| GET | /api/admin/dashboard, /api/admin/users, /api/admin/owners | admin only |
| GET/POST | /api/users | users:read / users:create |
| PATCH | /api/users/:id/role | users:assign_role |
| PATCH | /api/users/:id/status | users:update |
| DELETE | /api/users/:id | users:delete |
| GET/POST | /api/projects | own or all / projects:create |
| GET/PATCH/DELETE | /api/projects/:id | membership or staff |
| POST/DELETE | /api/projects/:id/members | projects:update |

## Protecting your own routes
```js
const { authenticate, requirePermission } = require('./middleware/auth');
const { PERMISSIONS } = require('./config/permissions');

router.post('/news', authenticate, requirePermission(PERMISSIONS.CONTENT_CREATE), handler);
```

## Frontend contract
- `accessToken` (15 min) goes in `Authorization: Bearer ...`.
- Refresh token lives in an httpOnly cookie; call `POST /api/auth/refresh` with `credentials: 'include'` when you get a 401.
